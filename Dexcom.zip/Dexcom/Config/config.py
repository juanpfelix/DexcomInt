class TestData:
    BASE_URL = "https://clarity.dexcom.com"
    LOGGED_IN_URL = "https://clarity.dexcom.com/#/welcome"

    USERNAME = 'codechallenge'
    PASSWORD = 'Password123'
