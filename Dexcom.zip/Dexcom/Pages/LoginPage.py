from .BasePage import BasePage
from selenium.webdriver.common.by import By

class LoginPage(BasePage):
    # Locators
    USERNAME_FIELD = (By.ID, 'username')
    PASSWORD_FIELD = (By.ID, 'password')
    LOGIN_BUTTON = (By.XPATH, "//div[@id='edit-actions']")
    LOGGED_IN_TITLE_LABEL = (By.XPATH, """//h1[contains(text(), "We Don't Have Your Data Yet")]""")

    def __init__(self, driver):
        super().__init__(driver)
       
    def login(self, username, pswd):
        self.send_keys(self.USERNAME_FIELD, username)
        self.send_keys(self.PASSWORD_FIELD, pswd)
        self.click(self.LOGIN_BUTTON)
        # Wait for page to load
        self.wait_for_element(self.LOGGED_IN_TITLE_LABEL)
