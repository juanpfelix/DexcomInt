from .BasePage import BasePage
from .LoginPage import LoginPage
from selenium.webdriver.common.by import By
from Config.config import TestData

class HomePage(BasePage):
    # Locators
    HOME_USERS_BUTTON = (By.XPATH, "//a[contains(text(), 'Dexcom CLARITY for Home Users')]")

    def __init__(self, driver=None):
        super().__init__(driver)
    
    def go_to_home_page(self):
        self.navigate_to_url(TestData.BASE_URL)
        # Wait for page to load
        self.wait_for_element(self.HOME_USERS_BUTTON)
    
    def go_to_login_page(self):
        self.click(self.HOME_USERS_BUTTON)
        # Wait for login page to load
        self.wait_for_element(LoginPage.USERNAME_FIELD)
        # Return login page object
        return LoginPage(self.driver)
