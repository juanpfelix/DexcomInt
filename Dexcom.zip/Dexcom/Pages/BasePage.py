from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage:
    driver = None

    def __init__(self, driver=None):
        if driver == None:
            options = webdriver.ChromeOptions()
            options.add_argument("--incognito")
            self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        else:
            self.driver = driver
    
    def navigate_to_url(self, url):
        try:
            self.driver.get(url)
        except:
            # LOG ERROR IN EXECUTION REPORT, for example: report.log('Could not navigate to url x')
            # Also, we could attach a screenshot to the report
            pass
    
    def click(self, by_locator, timeout=15):
        try:
            element = WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(by_locator))
            element.click()
            # LOG ACTION IN EXECUTION REPORT, for example: report.log('Successfully clicked element x')
        except:
            # LOG ERROR IN EXECUTION REPORT, for example: report.log('Could not click element x')
            # Also, we could attach a screenshot to the report
            pass
    
    def send_keys(self, by_locator, text, timeout=15):
        try:
            element = WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(by_locator))
            element.send_keys(text)
            # LOG ACTION IN EXECUTION REPORT, for example: report.log('Successfully typed '' in element x')
        except:
            # LOG ERROR IN EXECUTION REPORT, for example: report.log('Could not type '' in element x')
            # Also, we could attach a screenshot to the report
            pass
    
    def wait_for_element(self, by_locator, timeout=15):
        try:
            element = WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(by_locator))
        except:
            # LOG ERROR IN EXECUTION REPORT, for example: report.log('Wait for element x timed out')
            # Also, we could attach a screenshot to the report
            pass
    
    def close_driver(self):
        self.driver.close()
