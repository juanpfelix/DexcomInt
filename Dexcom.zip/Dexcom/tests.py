import unittest

from Pages.LoginPage import LoginPage
from Pages.HomePage import HomePage
from Config.config import TestData

# This class would be a test class that contains all the test methods to execute
class LoginPageTests(unittest.TestCase):
    def setUp(self):
        self.home_page = HomePage()
        self.home_page.go_to_home_page()
        self.login_page = self.home_page.go_to_login_page()
    
    def tearDown(self):
        self.login_page.close_driver()
    
    def test_login(self):
        self.login_page.login(TestData.USERNAME, TestData.PASSWORD)
        
        # Verify that the URL for logged in user is the expected URL
        expected_url = TestData.LOGGED_IN_URL
        actual_url = self.login_page.driver.current_url
        self.assertEqual(expected_url, actual_url, "Test Failed, URL should be: " + expected_url)

if __name__ == '__main__':
    unittest.main()
